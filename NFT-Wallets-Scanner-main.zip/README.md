
# NFT Wallets Scanner

This tool can scan list of wallets addresses on 3 NFT Networks with one click

## How to use



```javascript
1.Download the Portable executable file of Stable Version from releases

2.When you click on start the tool look like cracked but it not :)

3.This is tool is using nftscan API so if it slow or not working take your own API from nftscan.com & place it on API box, Enjoy
```



## Screenshots

![App Screenshot](https://github.com/AbdeLhalimSB/NFT-Wallets-Scanner/blob/main/NFT-Wallets-Scanner/img/Capture.PNG)

## Crypto Networks Supported

- Binance Smart Chain
- Ethereum
- Polygon

## ⚠️Disclaimer

This code is intended for educational and testing purposes only. Any use for unauthorized or unethical activities is not endorsed. The author is not responsible for any misuse of the code.
